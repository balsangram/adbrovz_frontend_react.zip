import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { Link, NavLink } from 'react-router-dom';
import { setPageTitle } from '../../../store/themeConfigSlice';
import DataTableComponent from '../../../components/common/DataTableComponent';
import IconEdit from '../../../components/Icon/IconEdit';
import IconEye from '../../../components/Icon/IconEye';
import IconTrashLines from '../../../components/Icon/IconTrashLines';
const rowData = [
    { id: 1, merchantName: 'Caroline', businessType: 'Jensen', email: 'carolinejensen@zidant.com', phone: '+1 (821) 447-3782', approvalStatus: 'Approved' },
    { id: 2, merchantName: 'Celeste', businessType: 'Grant', email: 'celestegrant@polarax.com', phone: '+1 (838) 515-3408', approvalStatus: 'Approved' },
    { id: 3, merchantName: 'Tillman', businessType: 'Forbes', email: 'tillmanforbes@manglo.com', phone: '+1 (969) 496-2892', approvalStatus: 'Approved' },
];
const columns = [
    { accessor: 'id', title: 'ID', sortable: true },
    { accessor: 'merchantName', title: 'Merchant', sortable: true },
    { accessor: 'businessType', title: 'Business Type', sortable: true },
    { accessor: 'email', title: 'Email', sortable: true },
    { accessor: 'phone', title: 'Phone No.', sortable: true },
    { accessor: 'approvalStatus', title: 'Approval Status', sortable: true },
    {
        accessor: 'action',
        title: 'Actions',
        sortable: false,
        render: ({ id }: { id: number }) => (
            <div className="flex gap-4 items-center w-max mx-auto">
                <NavLink to="/admin/merchants/edit" className="flex hover:text-info">
                    <IconEdit className="w-4.5 h-4.5" />
                </NavLink>
                <NavLink to="/apps/invoice/preview" className="flex hover:text-primary">
                    <IconEye />
                </NavLink>
            </div>
        ),
    },
];
const Merchants = () => {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setPageTitle('Dashboard'));
    });
    return (
        <div>
            <ul className="flex space-x-2 rtl:space-x-reverse">
                <li>
                    <Link to="/" className="text-primary hover:underline">
                        Dashboard
                    </Link>
                </li>
                <li className="before:content-['/'] ltr:before:mr-2 rtl:before:ml-2">
                    <span>Merchants</span>
                </li>
            </ul>
            <div>
                <DataTableComponent data={rowData} columns={columns} createPage="/admin/merchants/create" />
            </div>
        </div>
    );
};

export default Merchants;
